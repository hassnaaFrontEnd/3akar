/*global $ */
/*eslint-env browser*/

$(document).ready(function () {
    'use strict';
    
    var modify_home_model = $(".modify-model");
    $(".modifiy-btn").click(function () {
        modify_home_model.addClass("open");
    });
    $(".control-icon").click(function () {
        modify_home_model.removeClass("open");
    });
    $(".side-nav .control-side").click(function () {
        $(this).toggleClass("active");
        $('body').toggleClass("side-bar-icon");
        $(".side-nav .user-login").toggleClass("hidden");
    });
    $(".side-nav .control-side").click(function () {
        if (!$("body").hasClass("side-bar-icon")) {
            $(".main-panel").addClass("hide-phone");
        } else {
            $(".main-panel").removeClass("hide-phone");
        }
    });
    $('#accordionNav li a img').click(function () {
        if ($("body").hasClass("side-bar-icon")) {
            $("body").removeClass("side-bar-icon");
        }
    });
    //slider1
    $(".slider").owlCarousel({
        items: 5,
        loop: true,
        responsiveClass: true,
        nav: true,
        rtl : true,
        margin: 10,
        autoplay: true,
        autoplayTimeout: 4000,
        smartSpeed: 800,
        center: true,
        navText: ['<span class="fas fa-chevron-left"></span>', '<span class="fas fa-chevron-right"></span>']
    });
    //imagezoom
    $('#img_01').ezPlus({
        zoomWindowFadeIn: 500,
        zoomLensFadeIn: 500,
        gallery: 'gal1',
        imageCrossfade: true,
        zoomWindowWidth: 411,
        zoomWindowHeight: 274,
        zoomWindowOffsetX: 10,
        scrollZoom: true,
        cursor: 'pointer'
    });

    //pass the images to Fancybox
    $('#img_01').bind('click', function () {
        var ez = $('#img_01').data('ezPlus');
        $.fancyboxPlus(ez.getGalleryList());
        return false;
    });
    var tog_btn = $(".toggle-button .btn-toggle");
    if (tog_btn.hasClass(".active")) {
        $(".add-user-respons .add-respons").css({
            display: "block"
        });
    }
    $(".slider2").slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        nextArrow: ".opinions .arrows span.prev-arrow",
        prevArrow: ".opinions .arrows span.next-arrow",
        rtl: true
    });
    $(".home-toggle.active").click(function () {
        swal({
          title: "هل ترغب بإخفاء هذا الإعلان ؟",
          buttons: {
            
            catch: {
              text: "إخفاء",
              value: "catch",
            },
              cancel: "إلغاء"
          },
          dangerMode: true,
        })
        .then((willDelete) => {
             if (willDelete) {
                 swal("تم", {
                     icon: "success",
                 });
             } else {
                 swal("حسناً! تم الالغاء");
             }
         });
    });
    
    //home map
    $("#mytab li").click(function () {
        var data_scroll = $(this).data("scroll");
        $(this).addClass("active").siblings().removeClass("active");
        $(".pointes span").hide();
        $("." + data_scroll).fadeIn(100);
    });
   
});